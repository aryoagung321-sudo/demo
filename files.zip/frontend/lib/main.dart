import 'package:flutter/material.dart';
import 'screens/registration_screen.dart';

void main() {
  runApp(PinjolApp());
}

class PinjolApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pinjol UangMaju',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Roboto',
      ),
      home: RegistrationScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}