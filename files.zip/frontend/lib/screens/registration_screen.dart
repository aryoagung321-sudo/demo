// Tambahkan import untuk navigasi ke ProductScreen
import 'product_screen.dart';

// ...di dalam tombol 'Daftar'
onPressed: () async {
  if (_formKey.currentState!.validate()) {
    _formKey.currentState!.save();

    // [Permission handling di sini, seperti pada jawaban sebelumnya]

    // Kirim data ke backend
    final response = await http.post(
      Uri.parse('http://d.seoikrom.com/api/users/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        "nama": nama,
        "nik": nik,
        "email": email,
        "noHp": noHp,
        "provinsi": provinsi,
        "kota": kota,
        "kecamatan": kecamatan,
        "kelurahan": kelurahan,
        "alamat": alamat,
        "bank": bank,
        "norek": norek,
      }),
    );
    if (response.statusCode == 200) {
      // Setelah berhasil, misal userId didapat dari backend response
      final userId = jsonDecode(response.body)['user_id'];
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ProductScreen(userId: userId.toString()),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Registrasi gagal')),
      );
    }
  }
}