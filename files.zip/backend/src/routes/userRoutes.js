// Tambahkan setelah route register
router.post('/apply-loan', userController.applyLoan);